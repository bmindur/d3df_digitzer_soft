-------------------------------------------------------------------------------

                   --- CAEN SpA - Computing Division ---

                                www.caen.it

  -----------------------------------------------------------------------------

  Program: WaveDemo_x743
  Version: 1.2.1
  Date: April 2024

  -----------------------------------------------------------------------------

  System Requirements
  -----------------------------------------------------------------------------
  - Windows 10/11
  - GNUplot 4.2 or later (www.gnuplot.org)

  How to get support
  -----------------------------------------------------------------------------
  Our Software Support Group is available for questions, support and any other
  software related issue concerning CAEN products; for software support
  visit the page www.caen.it/computing/support.php or send an email to
  support.computing@caen.it
